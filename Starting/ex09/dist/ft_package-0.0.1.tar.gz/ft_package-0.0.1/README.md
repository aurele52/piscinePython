# ft_package

A sample Python package for counting occurrences of an item in a list.

## Installation

```bash
pip install ./dist/ft_package-0.0.1.tar.gz
# OR
pip install ./dist/ft_package-0.0.1-py3-none-any.whl

